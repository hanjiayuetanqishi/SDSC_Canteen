<?php
$page_title = 'Dashboard';
$nav = 'dashboard';
require_once __DIR__ . '/includes/header.php';

$pdo = getDB();
$totalOrders = (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$pending     = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$completed   = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'completed'")->fetchColumn();
$revenue     = (float)$pdo->query(
    "SELECT COALESCE(SUM(total),0) FROM orders WHERE status IN ('confirmed','preparing','ready','completed')"
)->fetchColumn();
?>
<div class="panel-header">
  <h3>Welcome, <?= e(current_user()['name']) ?></h3>
</div>
<div class="reports-grid">
  <div class="stat-card"><div class="num"><?= $totalOrders ?></div><div class="label">Total Orders</div></div>
  <div class="stat-card"><div class="num"><?= $pending ?></div><div class="label">Pending Payment</div></div>
  <div class="stat-card"><div class="num"><?= $completed ?></div><div class="label">Completed</div></div>
  <div class="stat-card"><div class="num"><?= format_money($revenue) ?></div><div class="label">Revenue</div></div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
