<?php
$page_title = 'Menu & Inventory';
$nav = 'menu';
require_once __DIR__ . '/includes/header.php';

$pdo = getDB();
$labels = category_labels();
$category = $_GET['cat'] ?? 'breakfast';
if (!isset($labels[$category])) $category = 'breakfast';

// Delete
if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM menu_items WHERE id = ?')->execute([$_GET['delete']]);
    flash('success', 'Item deleted.');
    redirect(base_url('admin/menu.php?cat=' . urlencode($category)));
}

// Toggle available
if (isset($_GET['toggle'])) {
    $pdo->prepare('UPDATE menu_items SET available = IF(available=1,0,1) WHERE id = ?')->execute([$_GET['toggle']]);
    flash('success', 'Availability updated.');
    redirect(base_url('admin/menu.php?cat=' . urlencode($category)));
}

// Quick qty update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['qty_id'], $_POST['quantity'])) {
    $pdo->prepare('UPDATE menu_items SET quantity = ? WHERE id = ?')
        ->execute([(int)$_POST['quantity'], $_POST['qty_id']]);
    flash('success', 'Quantity updated.');
    redirect(base_url('admin/menu.php?cat=' . urlencode($category)));
}

// Add / Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_item'])) {
    $id    = $_POST['item_id'] ?? '';
    $name  = trim($_POST['name'] ?? '');
    $cat   = $_POST['category'] ?? $category;
    $price = (float)($_POST['price'] ?? 0);
    $qty   = (int)($_POST['quantity'] ?? 0);
    $desc  = trim($_POST['description'] ?? '');
    $avail = isset($_POST['available']) ? 1 : 0;
    $qtyType = is_meal_category($cat) ? 'servings' : 'stock';
    $icons = [
        'breakfast'=>'🍳','lunch'=>'🍽️','merienda'=>'🥟','beverages'=>'🥤',
        'milk_dairy'=>'🥛','snacks_chips'=>'🥔','biscuits'=>'🍪','bread_pastries'=>'🍞',
        'chocolates'=>'🍬','instant_noodles'=>'🍜','ice_cream'=>'🍦',
    ];
    $icon = $icons[$cat] ?? '🍽️';

    if ($name === '' || $price < 0) {
        flash('error', 'Invalid name or price.');
    } elseif ($id) {
        $pdo->prepare('UPDATE menu_items SET name=?, category=?, price=?, quantity=?, description=?, available=?, qty_type=?, icon=? WHERE id=?')
            ->execute([$name, $cat, $price, $qty, $desc, $avail, $qtyType, $icon, $id]);
        flash('success', 'Item updated.');
    } else {
        $newId = 'item_' . bin2hex(random_bytes(5));
        $pdo->prepare('INSERT INTO menu_items (id,name,category,price,quantity,qty_type,description,available,icon) VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute([$newId, $name, $cat, $price, $qty, $qtyType, $desc, $avail, $icon]);
        flash('success', 'Item added.');
    }
    redirect(base_url('admin/menu.php?cat=' . urlencode($cat)));
}

$editItem = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM menu_items WHERE id = ?');
    $stmt->execute([$_GET['edit']]);
    $editItem = $stmt->fetch();
}

$stmt = $pdo->prepare('SELECT * FROM menu_items WHERE category = ? ORDER BY name');
$stmt->execute([$category]);
$items = $stmt->fetchAll();
$qLabel = is_meal_category($category) ? 'Servings' : 'Stock';
?>
<div class="panel-header">
  <h3>Menu Items &amp; Inventory</h3>
  <a href="#addForm" class="btn btn-primary sm" onclick="document.getElementById('addForm').style.display='block'">+ Add Item</a>
</div>

<div class="tabs small">
  <?php foreach ($labels as $key => $label): ?>
    <a class="tab <?= $category === $key ? 'active' : '' ?>" href="?cat=<?= e($key) ?>"><?= e($label) ?></a>
  <?php endforeach; ?>
</div>

<div id="addForm" class="card" style="<?= $editItem ? '' : 'display:none;' ?>margin-bottom:1.2rem;">
  <h3><?= $editItem ? 'Edit Item' : 'Add Menu Item' ?></h3>
  <form method="post">
    <input type="hidden" name="save_item" value="1" />
    <input type="hidden" name="item_id" value="<?= e($editItem['id'] ?? '') ?>" />
    <div class="form-group">
      <label>Item Name</label>
      <input type="text" name="name" required value="<?= e($editItem['name'] ?? '') ?>" />
    </div>
    <div class="form-group">
      <label>Category</label>
      <select name="category">
        <?php foreach ($labels as $key => $label): ?>
          <option value="<?= e($key) ?>" <?= ($editItem['category'] ?? $category) === $key ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label>Price (₱)</label>
        <input type="number" name="price" min="0" step="0.01" required value="<?= e($editItem['price'] ?? '') ?>" />
      </div>
      <div class="form-group">
        <label><?= e($qLabel) ?></label>
        <input type="number" name="quantity" min="0" value="<?= e($editItem['quantity'] ?? '10') ?>" />
      </div>
    </div>
    <div class="form-group">
      <label>Description</label>
      <input type="text" name="description" value="<?= e($editItem['description'] ?? '') ?>" />
    </div>
    <div class="form-group">
      <label><input type="checkbox" name="available" <?= !isset($editItem) || !empty($editItem['available']) ? 'checked' : '' ?> /> Available</label>
    </div>
    <button type="submit" class="btn btn-primary">Save Item</button>
    <?php if ($editItem): ?>
      <a href="?cat=<?= e($category) ?>" class="btn btn-outline">Cancel</a>
    <?php endif; ?>
  </form>
</div>

<div class="admin-menu-list">
<?php if (!$items): ?>
  <p style="text-align:center;color:#6b5344;padding:1.5rem;">No items yet.</p>
<?php endif; ?>
<?php foreach ($items as $item):
  $avail = (int)$item['available'] === 1;
?>
  <div class="admin-item <?= $avail ? '' : 'unavailable-row' ?>">
    <div class="admin-item-info">
      <h4><?= e(($item['icon'] ?: '') . ' ' . $item['name']) ?></h4>
      <span>
        <?= format_money((float)$item['price']) ?>
        · <?= e(qty_label($item['qty_type'])) ?>: <?= (int)$item['quantity'] ?>
        · <?= $avail ? 'Available' : 'Not Available' ?>
      </span>
    </div>
    <div class="admin-item-actions">
      <form method="post" style="display:inline;">
        <input type="hidden" name="qty_id" value="<?= e($item['id']) ?>" />
        <input type="number" class="stock-input" name="quantity" value="<?= (int)$item['quantity'] ?>" min="0" onchange="this.form.submit()" title="<?= e(qty_label($item['qty_type'])) ?>" />
      </form>
      <a href="?cat=<?= e($category) ?>&toggle=<?= e($item['id']) ?>" class="btn btn-outline sm">
        <?= $avail ? 'Set Unavailable' : 'Set Available' ?>
      </a>
      <a href="?cat=<?= e($category) ?>&edit=<?= e($item['id']) ?>" class="btn btn-outline sm">Edit</a>
      <a href="?cat=<?= e($category) ?>&delete=<?= e($item['id']) ?>" class="btn btn-outline sm" style="color:#c62828;border-color:#c62828;"
         onclick="return confirm('Delete this item?')">Del</a>
    </div>
  </div>
<?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
