<?php
$page_title = 'Kitchen Staff';
$nav = 'staff';
require_once __DIR__ . '/includes/header.php';
require_login(['superadmin']);

$pdo = getDB();
$users = $pdo->query('SELECT id, username, role, name, created_at FROM users ORDER BY role, username')->fetchAll();
$super = null;
$kitchens = [];
foreach ($users as $u) {
    if ($u['role'] === 'superadmin') $super = $u;
    else $kitchens[] = $u;
}
?>
<div class="panel-header">
  <h3>Kitchen Staff Accounts</h3>
  <p class="note">Maximum of 2 Kitchen Staff accounts. Fixed — cannot add or remove.</p>
</div>

<div class="staff-card">
  <div>
    <strong><?= e($super['name'] ?? 'Super Admin') ?></strong>
    <div class="role">Fixed — only one Super Admin account</div>
    <div style="font-size:0.85rem;margin-top:0.3rem;">Username: <?= e($super['username'] ?? 'superadmin') ?></div>
  </div>
</div>

<h4 style="margin:1.2rem 0 0.6rem;">Kitchen Staff (<?= count($kitchens) ?>/2)</h4>
<?php foreach ($kitchens as $s): ?>
<div class="staff-card">
  <div>
    <strong><?= e($s['name']) ?></strong>
    <div class="role">Kitchen Staff</div>
    <div style="font-size:0.85rem;margin-top:0.3rem;">Username: <?= e($s['username']) ?></div>
  </div>
</div>
<?php endforeach; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
