<?php
$page_title = 'Orders';
$nav = 'orders';
require_once __DIR__ . '/includes/header.php';

$pdo = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $oid = (int)$_POST['order_id'];
    $st  = $_POST['status'];
    $allowed = ['pending','confirmed','preparing','ready','completed','cancelled'];
    if (in_array($st, $allowed, true)) {
        $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$st, $oid]);
        flash('success', 'Order updated to ' . $st);
    }
    redirect(base_url('admin/orders.php?status=' . urlencode($_GET['status'] ?? 'all')));
}

$filter = $_GET['status'] ?? 'all';
if ($filter && $filter !== 'all') {
    $stmt = $pdo->prepare('SELECT * FROM orders WHERE status = ? ORDER BY created_at DESC');
    $stmt->execute([$filter]);
} else {
    $stmt = $pdo->query('SELECT * FROM orders ORDER BY created_at DESC');
}
$orders = $stmt->fetchAll();
?>
<div class="panel-header">
  <h3>All Orders</h3>
  <form method="get" style="margin:0;">
    <select name="status" onchange="this.form.submit()">
      <?php foreach (['all','pending','confirmed','preparing','ready','completed','cancelled'] as $s): ?>
        <option value="<?= $s ?>" <?= $filter === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<div class="orders-list">
<?php if (!$orders): ?>
  <p style="text-align:center;color:#6b5344;padding:2rem;">No orders found.</p>
<?php endif; ?>
<?php foreach ($orders as $o):
  $items = json_decode($o['items_json'], true) ?: [];
  $itemsStr = implode(', ', array_map(fn($i) => $i['name'] . ' ×' . $i['qty'], $items));
  $ref = order_ref((int)$o['order_number']);
?>
  <div class="order-card <?= e($o['status']) ?>">
    <div class="order-top">
      <div>
        <h4><?= e($ref) ?></h4>
        <div style="font-size:0.85rem;color:#6b5344;">
          School ID: <strong><?= e($o['school_id']) ?></strong>
          (<?= e(ucfirst($o['customer_type'])) ?>)
        </div>
        <div style="font-size:0.8rem;color:#6b5344;"><?= e(date('M d, Y h:i A', strtotime($o['created_at']))) ?></div>
      </div>
      <span class="badge <?= e($o['status']) ?>"><?= e($o['status']) ?></span>
    </div>
    <div class="order-items"><?= e($itemsStr) ?></div>
    <div style="display:flex;justify-content:space-between;margin-top:0.4rem;">
      <strong><?= format_money((float)$o['total']) ?></strong>
      <span style="font-size:0.8rem;text-transform:uppercase;"><?= e($o['payment']) ?></span>
    </div>
    <div class="order-actions">
      <?php if ($o['status'] === 'pending'): ?>
        <form method="post" style="display:inline;"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>" /><input type="hidden" name="status" value="confirmed" /><button class="btn btn-primary sm">✓ Approve Payment</button></form>
        <form method="post" style="display:inline;"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>" /><input type="hidden" name="status" value="cancelled" /><button class="btn btn-outline sm">Cancel</button></form>
      <?php elseif ($o['status'] === 'confirmed'): ?>
        <form method="post" style="display:inline;"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>" /><input type="hidden" name="status" value="preparing" /><button class="btn btn-secondary sm">Start Preparing</button></form>
      <?php elseif ($o['status'] === 'preparing'): ?>
        <form method="post" style="display:inline;"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>" /><input type="hidden" name="status" value="ready" /><button class="btn btn-primary sm">Mark Ready</button></form>
      <?php elseif ($o['status'] === 'ready'): ?>
        <form method="post" style="display:inline;"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>" /><input type="hidden" name="status" value="completed" /><button class="btn btn-primary sm">Complete</button></form>
      <?php endif; ?>
    </div>
  </div>
<?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
