<?php
$page_title = 'Reports';
$nav = 'reports';
require_once __DIR__ . '/includes/header.php';

$pdo = getDB();
$totalOrders = (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$completed   = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'completed'")->fetchColumn();
$pending     = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$revenue     = (float)$pdo->query(
    "SELECT COALESCE(SUM(total),0) FROM orders WHERE status IN ('confirmed','preparing','ready','completed')"
)->fetchColumn();

$today = date('Y-m-d');
$stmt = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE DATE(created_at) = ?');
$stmt->execute([$today]);
$todayOrders = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare(
    "SELECT COALESCE(SUM(total),0) FROM orders WHERE DATE(created_at) = ? AND status IN ('confirmed','preparing','ready','completed')"
);
$stmt->execute([$today]);
$todayRev = (float)$stmt->fetchColumn();
?>
<div class="panel-header">
  <h3>Sales Summary</h3>
</div>
<div class="reports-grid">
  <div class="stat-card"><div class="num"><?= $totalOrders ?></div><div class="label">Total Orders</div></div>
  <div class="stat-card"><div class="num"><?= $completed ?></div><div class="label">Completed</div></div>
  <div class="stat-card"><div class="num"><?= $pending ?></div><div class="label">Pending Payment</div></div>
  <div class="stat-card"><div class="num"><?= format_money($revenue) ?></div><div class="label">Total Revenue</div></div>
  <div class="stat-card"><div class="num"><?= $todayOrders ?></div><div class="label">Orders Today</div></div>
  <div class="stat-card"><div class="num"><?= format_money($todayRev) ?></div><div class="label">Revenue Today</div></div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
