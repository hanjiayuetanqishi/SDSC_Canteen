<?php
require_once __DIR__ . '/../../includes/functions.php';
require_login();
$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= e($page_title ?? 'Admin') ?> — Savian Canteen</title>
  <link rel="icon" type="image/svg+xml" href="<?= e(base_url('assets/img/logo-mark.svg')) ?>" />
  <link rel="stylesheet" href="<?= e(base_url('assets/css/styles.css')) ?>" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet" />
</head>
<body>
<header class="topbar">
  <h2><?= e($page_title ?? 'Dashboard') ?></h2>
  <div class="topbar-right">
    <span><?= e($user['name']) ?> (<?= e($user['role']) ?>)</span>
    <a href="<?= e(base_url('admin/logout.php')) ?>" class="btn btn-outline sm" style="color:#fff;border-color:rgba(255,255,255,0.5);">Logout</a>
  </div>
</header>
<div class="container">
  <nav class="admin-nav">
    <a class="nav-btn <?= ($nav ?? '') === 'dashboard' ? 'active' : '' ?>" href="<?= e(base_url('admin/dashboard.php')) ?>">Dashboard</a>
    <a class="nav-btn <?= ($nav ?? '') === 'orders' ? 'active' : '' ?>" href="<?= e(base_url('admin/orders.php')) ?>">Orders</a>
    <a class="nav-btn <?= ($nav ?? '') === 'menu' ? 'active' : '' ?>" href="<?= e(base_url('admin/menu.php')) ?>">Menu &amp; Inventory</a>
    <?php if ($user['role'] === 'superadmin'): ?>
    <a class="nav-btn <?= ($nav ?? '') === 'staff' ? 'active' : '' ?>" href="<?= e(base_url('admin/staff.php')) ?>">Kitchen Staff</a>
    <?php endif; ?>
    <a class="nav-btn <?= ($nav ?? '') === 'reports' ? 'active' : '' ?>" href="<?= e(base_url('admin/reports.php')) ?>">Reports</a>
  </nav>
