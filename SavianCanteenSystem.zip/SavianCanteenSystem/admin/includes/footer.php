</div>
<?php if (!empty($flash_error = flash('error'))): ?>
<script>alert(<?= json_encode($flash_error) ?>);</script>
<?php endif; ?>
<?php if (!empty($flash_success = flash('success'))): ?>
<script>alert(<?= json_encode($flash_success) ?>);</script>
<?php endif; ?>
</body>
</html>
