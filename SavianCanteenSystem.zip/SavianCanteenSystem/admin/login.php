<?php
require_once __DIR__ . '/../includes/functions.php';

if (is_logged_in()) {
    redirect(base_url('admin/dashboard.php'));
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && $user['password_hash'] === hash('sha256', $password)) {
        $_SESSION['user'] = [
            'id'       => $user['id'],
            'username' => $user['username'],
            'role'     => $user['role'],
            'name'     => $user['name'],
        ];
        redirect(base_url('admin/dashboard.php'));
    }
    $error = 'Invalid username or password.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login — Savian Canteen</title>
  <link rel="icon" type="image/svg+xml" href="<?= e(base_url('assets/img/logo-mark.svg')) ?>" />
  <link rel="stylesheet" href="<?= e(base_url('assets/css/styles.css')) ?>" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    /* Naka-center at mas malaking login card (para sa page na ito lang) */
    .admin-login-wrap {
      min-height: calc(100vh - 80px);   /* kabuuang taas minus topbar */
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
      box-sizing: border-box;
    }
    .admin-login-wrap .login-big {
      width: 100%;
      max-width: 560px;
      padding: 44px 40px;
      border-radius: 20px;
      box-sizing: border-box;
    }
    .admin-login-wrap .login-big h3 {
      font-size: 1.9rem;
      margin: 0 0 24px;
    }
    .admin-login-wrap .login-big .form-group { margin-bottom: 20px; }
    .admin-login-wrap .login-big label {
      font-size: 1rem;
      margin-bottom: 8px;
      display: block;
    }
    .admin-login-wrap .login-big input {
      width: 100%;
      box-sizing: border-box;
      padding: 18px 20px;
      font-size: 1.1rem;
      border-radius: 12px;
    }
    .admin-login-wrap .login-big .btn {
      padding: 18px;
      font-size: 1.15rem;
      margin-top: 6px;
    }
    .admin-login-wrap .login-big .note { font-size: 1rem; margin-bottom: 18px; }
    .admin-login-wrap .login-big .hint { font-size: .95rem; margin-top: 18px; }
  </style>
</head>
<body>
<header class="topbar">
  <a href="<?= e(base_url('index.php')) ?>" class="back-btn">← Back</a>
  <h2>Admin / Kitchen Login</h2>
  <div></div>
</header>

<div class="admin-login-wrap">
  <div class="card form-card login-big">
    <h3>Sign In</h3>
    <?php if ($error): ?>
      <p class="note" style="border-left-color:#c62828;"><?= e($error) ?></p>
    <?php endif; ?>
    <form method="post">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" required placeholder="Username" autofocus />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required placeholder="Password" />
      </div>
      <button type="submit" class="btn btn-primary full">Login</button>
    </form>
    <p class="hint">Super Admin &amp; Kitchen Staff only</p>
  </div>
</div>
</body>
</html>