<?php
$page_title = 'Your Cart';
$show_topbar = true;
require_once __DIR__ . '/includes/header.php';

if (empty($_SESSION['customer'])) {
    redirect(base_url('index.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cart = get_cart();
    if (isset($_POST['remove_id'])) {
        $cart = array_values(array_filter($cart, fn($c) => $c['id'] !== $_POST['remove_id']));
    }
    if (isset($_POST['qty_id'], $_POST['qty'])) {
        foreach ($cart as &$c) {
            if ($c['id'] === $_POST['qty_id']) {
                $c['qty'] = max(1, (int)$_POST['qty']);
                break;
            }
        }
        unset($c);
    }
    $_SESSION['cart'] = $cart;
    redirect(base_url('cart.php'));
}

$cart = get_cart();
?>
<div class="container narrow" style="padding-top:1.5rem;">
  <div class="card">
    <h3>Your Order</h3>
    <?php if (!$cart): ?>
      <p style="text-align:center;color:#6b5344;padding:1.5rem;">Cart is empty.</p>
      <a href="<?= e(base_url('menu.php')) ?>" class="btn btn-primary full">Back to Menu</a>
    <?php else: ?>
      <?php foreach ($cart as $c): ?>
      <div class="cart-item">
        <div class="cart-item-info">
          <h5><?= e(($c['icon'] ?? '') . ' ' . $c['name']) ?></h5>
          <span><?= format_money($c['price']) ?> × <?= (int)$c['qty'] ?></span>
        </div>
        <div class="qty-controls">
          <form method="post" style="display:inline;">
            <input type="hidden" name="qty_id" value="<?= e($c['id']) ?>" />
            <input type="hidden" name="qty" value="<?= (int)$c['qty'] - 1 ?>" />
            <button type="submit">−</button>
          </form>
          <span><?= (int)$c['qty'] ?></span>
          <form method="post" style="display:inline;">
            <input type="hidden" name="qty_id" value="<?= e($c['id']) ?>" />
            <input type="hidden" name="qty" value="<?= (int)$c['qty'] + 1 ?>" />
            <button type="submit">+</button>
          </form>
          <form method="post" style="display:inline;margin-left:0.4rem;">
            <input type="hidden" name="remove_id" value="<?= e($c['id']) ?>" />
            <button type="submit" style="color:#c62828;border-color:#c62828;">×</button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>
      <div class="total-row big">
        <span>Total</span>
        <strong><?= format_money(cart_total()) ?></strong>
      </div>
      <a href="<?= e(base_url('checkout.php')) ?>" class="btn btn-primary full">Proceed to Checkout</a>
      <a href="<?= e(base_url('menu.php')) ?>" class="btn btn-outline full" style="margin-top:0.6rem;">← Back to Menu</a>
    <?php endif; ?>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
