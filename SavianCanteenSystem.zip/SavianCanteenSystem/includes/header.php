<?php require_once __DIR__ . '/functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= e($page_title ?? 'Savian Canteen System') ?></title>
  <link rel="icon" type="image/svg+xml" href="<?= e(base_url('assets/img/logo-mark.svg')) ?>" />
  <link rel="stylesheet" href="<?= e(base_url('assets/css/styles.css')) ?>" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet" />
</head>
<body>
<?php if (!empty($show_topbar)): ?>
<header class="topbar">
  <a href="<?= e(base_url('index.php')) ?>" class="back-btn">← Home</a>
  <h2><?= e($page_title ?? 'Savian Canteen') ?></h2>
  <div class="topbar-right">
    <?php if (cart_count() > 0): ?>
      <a href="<?= e(base_url('cart.php')) ?>" class="cart-btn">🛒 <?= cart_count() ?></a>
    <?php else: ?>
      <span></span>
    <?php endif; ?>
  </div>
</header>
<?php endif; ?>
