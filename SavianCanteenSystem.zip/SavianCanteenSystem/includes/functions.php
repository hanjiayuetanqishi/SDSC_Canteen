<?php
require_once __DIR__ . '/../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Category labels for UI */
function category_labels(): array {
    return [
        'breakfast'      => 'Breakfast',
        'lunch'          => 'Lunch',
        'merienda'       => 'Merienda',
        'beverages'      => 'Beverages',
        'milk_dairy'     => 'Milk / Dairy',
        'snacks_chips'   => 'Snacks / Chips',
        'biscuits'       => 'Biscuits & Crackers',
        'bread_pastries' => 'Bread & Pastries',
        'chocolates'     => 'Chocolates / Candies',
        'instant_noodles'=> 'Instant Noodles',
        'ice_cream'      => 'Ice Cream / Frozen',
    ];
}

function is_meal_category(string $cat): bool {
    return in_array($cat, ['breakfast', 'lunch', 'merienda'], true);
}

function base_url(string $path = ''): string {
    $script = dirname($_SERVER['SCRIPT_NAME']);
    if (str_ends_with(str_replace('\\', '/', $script), '/admin')) {
        $script = dirname($script);
    }
    $base = rtrim(str_replace('\\', '/', $script), '/');
    if ($base === '' || $base === '/') $base = '';
    return $base . '/' . ltrim($path, '/');
}

function redirect(string $path): void {
    header('Location: ' . $path);
    exit;
}

function e(?string $str): string {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function flash(string $key, ?string $message = null): ?string {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }
    $msg = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $msg;
}

function is_logged_in(): bool {
    return !empty($_SESSION['user']);
}

function require_login(array $roles = []): void {
    if (!is_logged_in()) {
        redirect(base_url('admin/login.php'));
    }
    if ($roles && !in_array($_SESSION['user']['role'], $roles, true)) {
        flash('error', 'Access denied.');
        redirect(base_url('admin/dashboard.php'));
    }
}

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function get_cart(): array {
    return $_SESSION['cart'] ?? [];
}

function cart_count(): int {
    return array_sum(array_column(get_cart(), 'qty'));
}

function cart_total(): float {
    $total = 0;
    foreach (get_cart() as $item) {
        $total += $item['price'] * $item['qty'];
    }
    return $total;
}

function format_money(float $n): string {
    return '₱' . number_format($n, 2);
}

/** Display order ref: ORD-101 */
function order_ref(int $num): string {
    return 'ORD-' . $num;
}

function qty_label(string $qty_type): string {
    return $qty_type === 'servings' ? 'Servings' : 'Stock';
}

/** Guest ID, hal. G-261008-A3F1 */
function generate_guest_id(): string {
    return 'G-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
}