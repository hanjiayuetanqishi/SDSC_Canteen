<?php
require_once __DIR__ . '/includes/functions.php';
$order = $_SESSION['last_order'] ?? null;
if (!$order) {
    die('No order to print.');
}
$ref = order_ref((int)$order['order_number']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Receipt — <?= e($ref) ?></title>
  <link rel="stylesheet" href="<?= e(base_url('assets/css/styles.css')) ?>" />
  <style>
    body { background: #fff; }
    .receipt { max-width: 320px; margin: 1rem auto; padding: 1.5rem; font-size: 0.85rem; }
    @media print {
      body * { visibility: hidden; }
      .receipt, .receipt * { visibility: visible; }
      .receipt { position: absolute; left: 0; top: 0; width: 100%; }
      .no-print { display: none !important; }
    }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="receipt-header">
      <img src="<?= e(base_url('assets/img/logo-receipt.svg')) ?>" alt="Savian Canteen" class="receipt-logo" />
      <p><?= e(date('M d, Y h:i A', strtotime($order['created_at']))) ?></p>
    </div>
    <div class="receipt-body">
      <p><strong>Order Ref:</strong> <?= e($ref) ?></p>
      <p><strong>School ID:</strong> <?= e($order['school_id']) ?></p>
      <p><strong>Type:</strong> <?= e(ucfirst($order['customer_type'])) ?></p>
      <hr />
      <?php foreach ($order['items'] as $i): ?>
        <div style="display:flex;justify-content:space-between;">
          <span><?= e($i['name']) ?> × <?= (int)$i['qty'] ?></span>
          <span><?= format_money($i['price'] * $i['qty']) ?></span>
        </div>
      <?php endforeach; ?>
      <hr />
      <p class="r-total"><strong>TOTAL: <?= format_money((float)$order['total']) ?></strong></p>
      <p><strong>Payment:</strong> <?= e(strtoupper($order['payment'])) ?></p>
      <p><strong>Status:</strong> <?= e(strtoupper($order['status'])) ?></p>
    </div>
    <div class="receipt-footer">
      <p>Thank you for ordering!</p>
      <p>Present this receipt when claiming.</p>
    </div>
  </div>
  <div class="no-print" style="text-align:center;margin:1rem;">
    <button onclick="window.print()" class="btn btn-primary">Print</button>
    <button onclick="window.close()" class="btn btn-outline">Close</button>
  </div>
  <script>window.onload = function() { window.print(); }</script>
</body>
</html>
