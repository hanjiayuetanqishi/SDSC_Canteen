# Savian Canteen System

Multi-page PHP + MySQL canteen ordering system for **XAMPP**.

## What's new in this version

- **School ID only** for student & employee (no name, year, course, department, position)
- **Order numbers** start at 100 → display as `ORD-101`, `ORD-102`, …
- **New menu categories** and full food list
- **Meals** (Breakfast / Lunch / Merienda) use **Servings** instead of Stock
- **Available / Not Available** status — unavailable items are dimmed on the menu
- Fixed accounts: 1 Super Admin + max 2 Kitchen Staff

## Setup (XAMPP)

1. Copy `SavianCanteenSystem` to `C:\xampp\htdocs\`
2. Start Apache + MySQL
3. phpMyAdmin → **Import** → `database.sql`
4. Open: **http://localhost/SavianCanteenSystem/**

## Login

| Role | Username | Password |
|------|----------|----------|
| Super Admin | superadmin | admin123 |
| Kitchen Staff | kitchen1 | staff123 |
| Kitchen Staff | kitchen2 | staff123 |

## Order flow

1. Student / Employee enters **School ID only**
2. Browse menu → add to cart
3. Checkout → Cash / GCash / PayMaya / QR
4. Order Ref: `ORD-101` (increments from 100)
5. Receipt shows School ID + Order Ref

## Folder structure

```
SavianCanteenSystem/
├── admin/
│   ├── includes/
│   ├── dashboard.php
│   ├── orders.php
│   ├── menu.php
│   ├── staff.php
│   ├── reports.php
│   ├── login.php
│   └── logout.php
├── includes/
├── assets/
├── config/db.php
├── index.php
├── student_order.php
├── employee_order.php
├── menu.php
├── cart.php
├── checkout.php
├── order_success.php
├── receipt.php
└── database.sql
```
