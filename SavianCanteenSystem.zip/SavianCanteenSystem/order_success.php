<?php
$page_title = 'Order Placed';
require_once __DIR__ . '/includes/functions.php';

$order = $_SESSION['last_order'] ?? null;
if (!$order) {
    redirect(base_url('index.php'));
}
$isEwallet = in_array($order['payment'], ['gcash', 'paymaya', 'qr'], true);
$ref = order_ref((int)$order['order_number']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= e($page_title) ?> — Savian Canteen</title>
  <link rel="icon" type="image/svg+xml" href="<?= e(base_url('assets/img/logo-mark.svg')) ?>" />
  <link rel="stylesheet" href="<?= e(base_url('assets/css/styles.css')) ?>" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet" />
</head>
<body>
<div class="container narrow center" style="padding-top:2rem;">
  <div class="card success-card">
    <div class="success-icon">✓</div>
    <h2>Order Placed!</h2>
    <p>
      <?php if ($isEwallet): ?>
        Your order is <strong>Pending</strong>. Complete e-wallet payment and show proof to Kitchen Staff.
      <?php else: ?>
        Your order has been <strong>confirmed</strong>! Please wait for preparation.
      <?php endif; ?>
    </p>
    <p class="order-ref">
      School ID: <strong><?= e($order['school_id']) ?></strong><br />
      Order Ref: <strong><?= e($ref) ?></strong>
    </p>
    <div class="btn-row">
      <a href="<?= e(base_url('receipt.php')) ?>" class="btn btn-primary" target="_blank">🖨 Print Receipt</a>
      <a href="<?= e(base_url('index.php')) ?>" class="btn btn-secondary">New Order</a>
    </div>
  </div>
</div>
</body>
</html>
