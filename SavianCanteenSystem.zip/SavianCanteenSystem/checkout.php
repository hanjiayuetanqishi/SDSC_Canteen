<?php
$page_title = 'Checkout';
$show_topbar = true;
require_once __DIR__ . '/includes/header.php';

if (empty($_SESSION['customer']) || empty(get_cart())) {
    flash('error', 'Cart is empty.');
    redirect(base_url('menu.php'));
}

$cart = get_cart();
$customer = $_SESSION['customer'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment = strtolower(trim($_POST['payment'] ?? ''));
    $validPay = ['cash', 'gcash', 'paymaya', 'qr'];
    if (!in_array($payment, $validPay, true)) {
        flash('error', 'Please select a payment method.');
        redirect(base_url('checkout.php'));
    }

    $pdo = getDB();
    try {
        $pdo->beginTransaction();
        $cleanItems = [];
        $total = 0.0;

        foreach ($cart as $it) {
            $stmt = $pdo->prepare('SELECT * FROM menu_items WHERE id = ? FOR UPDATE');
            $stmt->execute([$it['id']]);
            $row = $stmt->fetch();
            $qty = (int)$it['qty'];

            if (!$row || !(int)$row['available'] || (int)$row['quantity'] < $qty) {
                throw new Exception('Insufficient quantity or item unavailable: ' . ($row['name'] ?? $it['name']));
            }

            $pdo->prepare('UPDATE menu_items SET quantity = quantity - ? WHERE id = ?')->execute([$qty, $row['id']]);

            $line = [
                'id'       => $row['id'],
                'name'     => $row['name'],
                'price'    => (float)$row['price'],
                'qty'      => $qty,
                'icon'     => $row['icon'] ?: '🍽️',
                'qty_type' => $row['qty_type'],
            ];
            $total += $line['price'] * $qty;
            $cleanItems[] = $line;
        }

        $isEwallet = in_array($payment, ['gcash', 'paymaya', 'qr'], true);
        $status = $isEwallet ? 'pending' : 'confirmed';

        $max = (int)$pdo->query('SELECT COALESCE(MAX(order_number), 100) FROM orders')->fetchColumn();
        $orderNumber = $max + 1;

        $pdo->prepare(
            'INSERT INTO orders (order_number, school_id, customer_type, items_json, total, payment, status)
             VALUES (?,?,?,?,?,?,?)'
        )->execute([
            $orderNumber,
            $customer['school_id'],
            $customer['type'],
            json_encode($cleanItems, JSON_UNESCAPED_UNICODE),
            $total,
            $payment,
            $status,
        ]);

        $pdo->commit();

        $_SESSION['last_order'] = [
            'order_number'  => $orderNumber,
            'school_id'     => $customer['school_id'],
            'customer_type' => $customer['type'],
            'items'         => $cleanItems,
            'total'         => $total,
            'payment'       => $payment,
            'status'        => $status,
            'created_at'    => date('Y-m-d H:i:s'),
        ];
        $_SESSION['cart'] = [];
        redirect(base_url('order_success.php'));

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', $e->getMessage());
        redirect(base_url('checkout.php'));
    }
}
?>
<div class="container narrow" style="padding-top:1.5rem;">
  <div class="card">
    <h3>Order Summary</h3>
    <p style="font-size:0.85rem;color:#6b5344;margin-bottom:0.75rem;">
      School ID: <strong><?= e($customer['school_id']) ?></strong>
      (<?= e(ucfirst($customer['type'])) ?>)
    </p>
    <?php foreach ($cart as $c): ?>
      <div style="display:flex;justify-content:space-between;padding:0.4rem 0;font-size:0.9rem;">
        <span><?= e($c['name']) ?> × <?= (int)$c['qty'] ?></span>
        <span><?= format_money($c['price'] * $c['qty']) ?></span>
      </div>
    <?php endforeach; ?>
    <div class="total-row big">
      <span>Total Amount</span>
      <strong><?= format_money(cart_total()) ?></strong>
    </div>
  </div>

  <div class="card">
    <h3>Payment Method</h3>
    <form method="post">
      <div class="payment-options">
        <label class="pay-opt"><input type="radio" name="payment" value="cash" checked /> <span>💵 Cash</span></label>
        <label class="pay-opt"><input type="radio" name="payment" value="gcash" /> <span>📱 GCash</span></label>
        <label class="pay-opt"><input type="radio" name="payment" value="paymaya" /> <span>📱 PayMaya</span></label>
        <label class="pay-opt"><input type="radio" name="payment" value="qr" /> <span>📷 QR Code</span></label>
      </div>
      <p class="note" id="ewalletNote" style="display:none;">
        ⚠️ For e-wallet: Pay first and show proof to Kitchen Staff.
        Order stays <strong>Pending</strong> until they approve.
      </p>
      <button type="submit" class="btn btn-primary full">Place Order</button>
    </form>
  </div>
</div>
<script>
document.querySelectorAll('input[name="payment"]').forEach(function(r) {
  r.addEventListener('change', function() {
    document.getElementById('ewalletNote').style.display =
      ['gcash','paymaya','qr'].includes(this.value) ? 'block' : 'none';
  });
});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
