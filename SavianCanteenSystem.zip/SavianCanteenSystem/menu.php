<?php
$page_title = 'Canteen Menu';
$show_topbar = true;
require_once __DIR__ . '/includes/header.php';

if (empty($_SESSION['customer'])) {
    flash('error', 'Please enter your School ID first.');
    redirect(base_url('index.php'));
}

$customer = $_SESSION['customer'];
$labels = category_labels();
$category = $_GET['cat'] ?? 'breakfast';
if (!isset($labels[$category])) $category = 'breakfast';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_id'])) {
    $addId = $_POST['add_id'];
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT * FROM menu_items WHERE id = ?');
    $stmt->execute([$addId]);
    $item = $stmt->fetch();
    if ($item && (int)$item['available'] === 1 && (int)$item['quantity'] > 0) {
        $cart = get_cart();
        $found = false;
        foreach ($cart as &$c) {
            if ($c['id'] === $addId) {
                if ($c['qty'] < (int)$item['quantity']) $c['qty']++;
                else flash('error', 'Not enough ' . qty_label($item['qty_type']) . '.');
                $found = true;
                break;
            }
        }
        unset($c);
        if (!$found) {
            $cart[] = [
                'id'       => $item['id'],
                'name'     => $item['name'],
                'price'    => (float)$item['price'],
                'qty'      => 1,
                'icon'     => $item['icon'] ?: '🍽️',
                'qty_type' => $item['qty_type'],
            ];
        }
        $_SESSION['cart'] = $cart;
    }
    redirect(base_url('menu.php?cat=' . urlencode($category)));
}

$pdo = getDB();
$stmt = $pdo->prepare('SELECT * FROM menu_items WHERE category = ? ORDER BY name');
$stmt->execute([$category]);
$items = $stmt->fetchAll();

$typeLabel = ($customer['type'] ?? '') === 'employee' ? 'Employee' : 'Student';
$info = e($typeLabel) . ' · School ID: <strong>' . e($customer['school_id']) . '</strong>';
?>
<div class="container">
  <div class="order-info-bar">🪪 <?= $info ?></div>

  <div class="tabs">
    <?php foreach ($labels as $key => $label): ?>
      <a class="tab <?= $category === $key ? 'active' : '' ?>"
         href="<?= e(base_url('menu.php?cat=' . $key)) ?>"><?= e($label) ?></a>
    <?php endforeach; ?>
  </div>

  <div class="menu-grid">
    <?php if (!$items): ?>
      <p style="grid-column:1/-1;text-align:center;color:#6b5344;padding:2rem;">No items in this category.</p>
    <?php endif; ?>
    <?php foreach ($items as $item):
      $avail = (int)$item['available'] === 1;
      $qty = (int)$item['quantity'];
      $out = !$avail || $qty <= 0;
      $low = $qty > 0 && $qty <= 5;
      $qLabel = qty_label($item['qty_type']);
    ?>
    <div class="menu-item <?= $out ? 'unavailable' : '' ?>">
      <div class="menu-item-img"><?= e($item['icon'] ?: '🍽️') ?></div>
      <div class="menu-item-body">
        <h4><?= e($item['name']) ?></h4>
        <p class="desc"><?= e($item['description']) ?></p>
        <div class="menu-item-footer">
          <div>
            <div class="price"><?= format_money((float)$item['price']) ?></div>
            <?php if (!$avail): ?>
              <span class="badge-status unavailable">Not Available</span>
            <?php elseif ($qty <= 0): ?>
              <div class="stock low">Out of <?= strtolower($qLabel) ?></div>
            <?php else: ?>
              <div class="stock <?= $low ? 'low' : '' ?>"><?= e($qLabel) ?>: <?= $qty ?></div>
              <span class="badge-status available">Available</span>
            <?php endif; ?>
          </div>
          <?php if (!$out): ?>
          <form method="post" style="margin:0;">
            <input type="hidden" name="add_id" value="<?= e($item['id']) ?>" />
            <button type="submit" class="add-btn" title="Add">+</button>
          </form>
          <?php else: ?>
          <button class="add-btn" disabled>+</button>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <?php if (cart_count() > 0): ?>
  <div style="text-align:center;margin:2rem 0;">
    <a href="<?= e(base_url('cart.php')) ?>" class="btn btn-primary">View Cart (<?= cart_count() ?>) — <?= format_money(cart_total()) ?></a>
  </div>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
