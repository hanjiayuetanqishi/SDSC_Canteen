-- ============================================================
-- Savian Canteen System
-- Database: savian_canteen
-- Import in phpMyAdmin (XAMPP)
-- ============================================================

CREATE DATABASE IF NOT EXISTS savian_canteen
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE savian_canteen;

-- ---------- USERS (Super Admin + Kitchen Staff only) ----------
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('superadmin','kitchen') NOT NULL,
  name          VARCHAR(100) NOT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- password = SHA256
-- superadmin / admin123
-- kitchen1 / staff123
-- kitchen2 / staff123
INSERT INTO users (username, password_hash, role, name) VALUES
('superadmin', SHA2('admin123', 256), 'superadmin', 'Super Admin'),
('kitchen1',   SHA2('staff123', 256), 'kitchen',    'Kitchen Staff 1'),
('kitchen2',   SHA2('staff123', 256), 'kitchen',    'Kitchen Staff 2');

-- ---------- MENU ITEMS ----------
-- qty_type: 'servings' for meals, 'stock' for everything else
CREATE TABLE menu_items (
  id          VARCHAR(32)  PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  category    VARCHAR(40)  NOT NULL,
  price       DECIMAL(10,2) NOT NULL DEFAULT 0,
  quantity    INT NOT NULL DEFAULT 0,
  qty_type    ENUM('stock','servings') NOT NULL DEFAULT 'stock',
  description VARCHAR(255) DEFAULT '',
  available   TINYINT(1) NOT NULL DEFAULT 1,
  icon        VARCHAR(16) DEFAULT '🍽️',
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ---------- ORDERS ----------
-- order numbers: sequential starting at 100 → display as ORD-101, ORD-102...
CREATE TABLE orders (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number  INT UNSIGNED NOT NULL UNIQUE,
  school_id     VARCHAR(50)  NOT NULL,
  customer_type ENUM('student','employee') NOT NULL,
  items_json    TEXT NOT NULL,
  total         DECIMAL(10,2) NOT NULL,
  payment       ENUM('cash','gcash','paymaya','qr') NOT NULL,
  status        ENUM('pending','confirmed','preparing','ready','completed','cancelled') NOT NULL DEFAULT 'pending',
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Start order_number sequence at 100 (first order will be 101)
ALTER TABLE orders AUTO_INCREMENT = 101;

-- ============================================================
-- SEED MENU
-- ============================================================

-- BEVERAGES
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('bev_vitamilk', 'Vitamilk', 'beverages', 25.00, 50, 'stock', 'Vitamilk soy milk drink', 1, '🥛'),
('bev_coke', 'Coca-Cola', 'beverages', 30.00, 50, 'stock', 'Coca-Cola soft drink', 1, '🥤'),
('bev_sprite', 'Sprite', 'beverages', 30.00, 45, 'stock', 'Sprite soft drink', 1, '🥤'),
('bev_c2', 'C2', 'beverages', 25.00, 40, 'stock', 'C2 green tea drink', 1, '🧃'),
('bev_chuckie', 'Chuckie', 'beverages', 20.00, 40, 'stock', 'Chuckie chocolate milk', 1, '🥛'),
('bev_water', 'Bottled Water', 'beverages', 15.00, 60, 'stock', 'Purified bottled water', 1, '💧');

-- MILK / DAIRY DRINKS
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('milk_nescafe', 'Nescafé 2in1 Sachet', 'milk_dairy', 12.00, 80, 'stock', 'Nescafé 2in1 coffee sachet', 1, '☕'),
('milk_bearbrand', 'Bear Brand Milk Sachet', 'milk_dairy', 12.00, 80, 'stock', 'Bear Brand powdered milk sachet', 1, '🥛'),
('milk_milo', 'Milo Sachet', 'milk_dairy', 12.00, 80, 'stock', 'Milo chocolate malt sachet', 1, '🍫'),
('milk_birchtree', 'Birch Tree Milk Sachet', 'milk_dairy', 12.00, 80, 'stock', 'Birch Tree milk sachet', 1, '🥛');

-- SNACKS / CHIPS
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('chip_vcut', 'V-Cut', 'snacks_chips', 20.00, 40, 'stock', 'V-Cut potato chips', 1, '🥔'),
('chip_nova', 'Nova', 'snacks_chips', 18.00, 40, 'stock', 'Nova corn chips', 1, '🌽'),
('chip_piattos_cheese', 'Piattos Cheese', 'snacks_chips', 20.00, 35, 'stock', 'Piattos Cheese flavor', 1, '🧀'),
('chip_piattos_sour', 'Piattos Sour & Cream', 'snacks_chips', 20.00, 35, 'stock', 'Piattos Sour Cream flavor', 1, '🧀'),
('chip_clover', 'Clover', 'snacks_chips', 15.00, 40, 'stock', 'Clover chips', 1, '🍀'),
('chip_chippy', 'Chippy', 'snacks_chips', 15.00, 40, 'stock', 'Chippy corn snacks', 1, '🌽');

-- BISCUITS & CRACKERS
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('bisc_fita', 'Fita', 'biscuits', 10.00, 50, 'stock', 'Fita crackers', 1, '🍪'),
('bisc_fita_spreadz', 'Fita Spreadz', 'biscuits', 12.00, 40, 'stock', 'Fita Spreadz crackers', 1, '🍪'),
('bisc_hansel', 'Hansel', 'biscuits', 10.00, 50, 'stock', 'Hansel chocolate biscuits', 1, '🍪');

-- BREAD & PASTRIES
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('bread_mamon', 'Special Mamon', 'bread_pastries', 25.00, 30, 'stock', 'Special soft mamon', 1, '🍞'),
('bread_crossini', 'Crossini', 'bread_pastries', 20.00, 30, 'stock', 'Crossini pastry', 1, '🥐');

-- CHOCOLATES / CANDIES
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('choc_max', 'Max', 'chocolates', 8.00, 60, 'stock', 'Max candy', 1, '🍬'),
('choc_vfresh', 'Vfresh', 'chocolates', 8.00, 60, 'stock', 'Vfresh candy', 1, '🍬'),
('choc_snowbear', 'Snowbear', 'chocolates', 10.00, 50, 'stock', 'Snowbear candy', 1, '🐻'),
('choc_xo', 'X.O', 'chocolates', 10.00, 50, 'stock', 'X.O candy', 1, '🍬');

-- INSTANT FOOD / NOODLES
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('nood_luckyme', 'Lucky Me!', 'instant_noodles', 20.00, 40, 'stock', 'Lucky Me! instant noodles', 1, '🍜');

-- ICE CREAM / FROZEN DESSERTS
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('ice_creamline', 'Creamline', 'ice_cream', 25.00, 30, 'stock', 'Creamline ice cream', 1, '🍦'),
('ice_popsipop', 'Popsipop', 'ice_cream', 15.00, 40, 'stock', 'Popsipop ice candy', 1, '🍭'),
('ice_pinoy', 'Pinoy Classics', 'ice_cream', 20.00, 30, 'stock', 'Pinoy Classics ice cream', 1, '🍦'),
('ice_fruitlolly', 'Fruit Lolly', 'ice_cream', 15.00, 40, 'stock', 'Fruit Lolly popsicle', 1, '🍭'),
('ice_creamcoolers', 'Cream Coolers', 'ice_cream', 25.00, 25, 'stock', 'Cream Coolers', 1, '🍦'),
('ice_creambar', 'Cream Bar', 'ice_cream', 20.00, 30, 'stock', 'Cream Bar', 1, '🍫'),
('ice_minicup', 'Mini Cup', 'ice_cream', 25.00, 30, 'stock', 'Ice cream mini cup', 1, '🍨'),
('ice_sundaecup', 'Sundae Cup', 'ice_cream', 35.00, 25, 'stock', 'Sundae cup', 1, '🍨'),
('ice_creamcup', 'Cream Cup', 'ice_cream', 30.00, 25, 'stock', 'Cream cup', 1, '🍨'),
('ice_pinipig', 'Pinipig', 'ice_cream', 25.00, 25, 'stock', 'Pinipig ice cream', 1, '🍦'),
('ice_creamcones', 'Cream Cones', 'ice_cream', 30.00, 30, 'stock', 'Cream cone', 1, '🍦'),
('ice_jumbocones', 'Jumbo Cones', 'ice_cream', 40.00, 25, 'stock', 'Jumbo cream cone', 1, '🍦'),
('ice_goldbar', 'Gold Bar', 'ice_cream', 35.00, 20, 'stock', 'Gold Bar ice cream', 1, '🍫'),
('ice_familyduo', 'Family Duo', 'ice_cream', 120.00, 15, 'stock', 'Family Duo pack', 1, '🍨'),
('ice_1_3liter', '1.3 Liter', 'ice_cream', 180.00, 10, 'stock', '1.3 Liter tub', 1, '🍨'),
('ice_3liter', '3 Liter', 'ice_cream', 280.00, 8, 'stock', '3 Liter tub', 1, '🍨');

-- BREAKFAST (servings)
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('bf_hotdog', 'Hotdog', 'breakfast', 25.00, 40, 'servings', 'Fried hotdog', 1, '🌭'),
('bf_egg', 'Egg', 'breakfast', 15.00, 50, 'servings', 'Fried egg', 1, '🥚'),
('bf_embutido', 'Embutido', 'breakfast', 30.00, 25, 'servings', 'Embutido slice', 1, '🍖'),
('bf_longganisa', 'Longganisa', 'breakfast', 35.00, 30, 'servings', 'Longganisa', 1, '🌭'),
('bf_rice', 'Rice', 'breakfast', 15.00, 60, 'servings', 'Plain steamed rice', 1, '🍚'),
('bf_friedrice', 'Fried Rice', 'breakfast', 25.00, 40, 'servings', 'Garlic fried rice', 1, '🍚');

-- LUNCH (servings)
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('ln_friedrice', 'Fried Rice', 'lunch', 25.00, 40, 'servings', 'Garlic fried rice', 1, '🍚'),
('ln_rice', 'Rice', 'lunch', 15.00, 60, 'servings', 'Plain steamed rice', 1, '🍚'),
('ln_menudo', 'Menudo', 'lunch', 55.00, 25, 'servings', 'Pork menudo', 1, '🍲'),
('ln_friedchicken', 'Fried Chicken', 'lunch', 65.00, 30, 'servings', 'Crispy fried chicken', 1, '🍗'),
('ln_chickencurry', 'Chicken Curry', 'lunch', 60.00, 25, 'servings', 'Chicken curry', 1, '🍛'),
('ln_pattybeef', 'Patty Beef Steak', 'lunch', 70.00, 20, 'servings', 'Beef patty steak', 1, '🥩'),
('ln_porkkawali', 'Pork Kawali', 'lunch', 70.00, 20, 'servings', 'Crispy pork kawali', 1, '🥓'),
('ln_bangus', 'Bangus', 'lunch', 65.00, 20, 'servings', 'Fried / grilled bangus', 1, '🐟'),
('ln_adobo', 'Adobo', 'lunch', 55.00, 30, 'servings', 'Chicken / pork adobo', 1, '🍲'),
('ln_ginataang', 'Ginataang Kalabasa', 'lunch', 45.00, 20, 'servings', 'Ginataang kalabasa', 1, '🎃'),
('ln_chopsuey', 'Chopsuey', 'lunch', 45.00, 25, 'servings', 'Vegetable chopsuey', 1, '🥬');

-- MERIENDA (servings)
INSERT INTO menu_items (id, name, category, price, quantity, qty_type, description, available, icon) VALUES
('mr_burger', 'Burger', 'merienda', 40.00, 30, 'servings', 'Classic burger', 1, '🍔'),
('mr_pancit', 'Pancit', 'merienda', 40.00, 25, 'servings', 'Pancit noodles', 1, '🍜'),
('mr_lumpia', 'Lumpiang Togue', 'merienda', 25.00, 30, 'servings', 'Lumpiang togue', 1, '🥟'),
('mr_palabok', 'Palabok', 'merienda', 45.00, 20, 'servings', 'Pancit palabok', 1, '🍜'),
('mr_bananacue', 'Banana Cue', 'merienda', 20.00, 35, 'servings', 'Banana cue', 1, '🍌'),
('mr_turon', 'Turon', 'merienda', 20.00, 35, 'servings', 'Banana turon', 1, '🍌'),
('mr_pancake', 'Pancake', 'merienda', 25.00, 30, 'servings', 'Pancake', 1, '🥞');
