<?php
/**
 * Savian Canteen System — Database Config (XAMPP)
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'savian_canteen');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('<h2 style="font-family:sans-serif;color:#5C3A21;padding:2rem;">Database connection failed.</h2>
                 <p style="font-family:sans-serif;padding:0 2rem;">Import <code>database.sql</code> in phpMyAdmin, then check <code>config/db.php</code>.</p>');
        }
    }
    return $pdo;
}
