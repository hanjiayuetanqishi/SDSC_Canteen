<?php
$page_title = 'Guest / Outsider Order';
$show_topbar = true;
require_once __DIR__ . '/includes/header.php';

// Isang guest ID lang bawat pagbisita (hindi nagbabago kapag nag-refresh)
if (empty($_SESSION['guest_pending_id'])) {
    $_SESSION['guest_pending_id'] = generate_guest_id();
}
$guest_id = $_SESSION['guest_pending_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['customer'] = [
        'type'      => 'guest',
        'school_id' => $guest_id,   // G-YYMMDD-XXXX, kaya lalabas pa rin sa history at reports
    ];
    $_SESSION['cart'] = [];
    unset($_SESSION['guest_pending_id']);
    redirect(base_url('menu.php'));
}
?>
<div class="container narrow" style="padding-top:1.5rem;">
  <div class="card form-card">
    <h3>Guest / Outsider Order</h3>
    <p class="hint" style="text-align:left;margin-bottom:1rem;">
      Hindi mo kailangan ng School ID. Gagawan ka ng sariling Guest ID para makita pa rin ang order mo sa kitchen at admin.
    </p>
    <div class="form-group">
      <label>Your Guest ID</label>
      <input type="text" value="<?= e($guest_id) ?>" readonly style="font-weight:600;letter-spacing:1px;" />
    </div>
    <p class="hint" style="text-align:left;margin-bottom:1rem;">
      Itala ang ID na ito. Ito ang gagamitin kung kailangan mong i-check ang order mo.
    </p>
    <form method="post">
      <button type="submit" class="btn btn-primary full">Continue to Menu →</button>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>