<?php
$page_title = 'Employee Order';
$show_topbar = true;
require_once __DIR__ . '/includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $school_id = strtoupper(trim($_POST['school_id'] ?? ''));
    if ($school_id === '') {
        flash('error', 'Please enter your School ID Number.');
        redirect(base_url('employee_order.php'));
    }
    // Employee ID dapat nagsisimula sa E
    if (detect_customer_type($school_id) !== 'employee') {
        flash('error', 'Wrong credentials. Please check your ID Number.');
        redirect(base_url('employee_order.php'));
    }
    $_SESSION['customer'] = [
        'type'      => 'employee',
        'school_id' => $school_id,
    ];
    $_SESSION['cart'] = [];
    redirect(base_url('menu.php'));
}
?>
<div class="container narrow" style="padding-top:1.5rem;">
  <div class="card form-card">
    <h3>Employee Order</h3>
    <p class="hint" style="text-align:left;margin-bottom:1rem;">Enter your School ID Number only. No other details needed.</p>
    <form method="post">
      <div class="form-group">
        <label>School ID Number</label>
        <input type="text" name="school_id" required placeholder="Enter your ID Number" autofocus style="text-transform:uppercase;" />
      </div>
      <button type="submit" class="btn btn-primary full">Continue to Menu →</button>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>