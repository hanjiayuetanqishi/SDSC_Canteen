<?php
$page_title = 'Savian Canteen System';
require_once __DIR__ . '/includes/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$enable_guest = true;   // gawing false para mawala ang Guest option
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'login';

    if ($action === 'guest' && $enable_guest) {
        $_SESSION['customer'] = [
            'type'      => 'guest',
            'school_id' => generate_guest_id(),
        ];
        $_SESSION['cart'] = [];
        redirect(base_url('menu.php'));
    }

    $school_id = strtoupper(trim($_POST['school_id'] ?? ''));
    $type = ($_POST['role'] ?? 'student') === 'employee' ? 'employee' : 'student';

    if ($school_id === '') {
        $error = 'Please enter your ID Number.';
    } else {
        $_SESSION['customer'] = [
            'type'      => $type,
            'school_id' => $school_id,
        ];
        $_SESSION['cart'] = [];
        redirect(base_url('menu.php'));
    }
}
$selected_role = ($_POST['role'] ?? 'student') === 'employee' ? 'employee' : 'student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= e($page_title) ?></title>
  <link rel="icon" type="image/svg+xml" href="<?= e(base_url('assets/img/logo-mark.svg')) ?>" />
  <link rel="stylesheet" href="<?= e(base_url('assets/css/styles.css')) ?>" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet" />
  <style>
    .landing-hero {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 24px;
    }
    .landing-hero .logo-img { width: 340px; max-width: 90%; height: auto; }
    .landing-hero .tagline { font-size: 1.6rem; margin-top: 14px; }
    .landing-hero .sub { font-size: 1.05rem; margin-bottom: 28px; }

    .landing-btns {
      width: 100%;
      max-width: 460px;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .landing-btns .btn {
      display: block;
      width: 100%;
      padding: 18px 24px;
      font-size: 1.1rem;
      box-sizing: border-box;
      text-align: center;
      cursor: pointer;
      font-family: inherit;
    }

    /* Login pop-up (naka-center at malaki) */
    .role-modal {
      position: fixed;
      inset: 0;
      margin: auto;
      height: fit-content;
      border: none;
      border-radius: 20px;
      padding: 40px 36px;
      width: 92%;
      max-width: 560px;
      background: #fbf3e4;
      box-shadow: 0 24px 60px rgba(92,58,30,.35);
      text-align: center;
      box-sizing: border-box;
    }
    .role-modal::backdrop { background: rgba(60,35,15,.45); }
    .role-modal h3 {
      margin: 0 0 8px;
      font-family: 'Playfair Display', serif;
      color: #5c3a1e;
      font-size: 1.9rem;
    }
    .role-modal p.lead { margin: 0 0 20px; color: #8b5e3c; font-size: 1.05rem; }

    /* Student / Employee toggle */
    .role-toggle {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-bottom: 16px;
    }
    .role-toggle input { position: absolute; opacity: 0; pointer-events: none; }
    .role-toggle label {
      padding: 14px;
      font-size: 1.05rem;
      font-weight: 600;
      border-radius: 12px;
      border: 1.5px solid #c9a24a;
      color: #7a5a1e;
      cursor: pointer;
      transition: all .15s ease;
    }
    .role-toggle input:checked + label {
      background: linear-gradient(135deg, #8b5e3c, #5c3a1e);
      border-color: #5c3a1e;
      color: #fff;
    }
    .role-toggle input:focus-visible + label { outline: 2px solid #c9a24a; outline-offset: 2px; }

    .role-modal input[type="text"] {
      width: 100%;
      box-sizing: border-box;
      padding: 18px 20px;
      font-size: 1.15rem;
      font-family: inherit;
      border: 1.5px solid #c9a24a;
      border-radius: 12px;
      background: #fff;
      text-transform: uppercase;
      margin-bottom: 18px;
    }
    .role-modal .error-msg {
      background: #fdecea;
      color: #b3261e;
      border-radius: 10px;
      padding: 12px 14px;
      font-size: 1rem;
      margin-bottom: 16px;
    }
    .role-modal .btn {
      display: block;
      width: 100%;
      padding: 18px;
      font-size: 1.1rem;
      box-sizing: border-box;
      text-align: center;
      cursor: pointer;
      font-family: inherit;
    }
    .role-modal .divider { margin: 20px 0 16px; color: #a98a68; font-size: .95rem; }
    .role-modal .close-link {
      margin-top: 18px;
      background: none;
      border: none;
      color: #8b5e3c;
      cursor: pointer;
      font-family: inherit;
      font-size: 1rem;
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="landing-hero">
    <div class="gold-accent"></div>
    <img src="<?= e(base_url('assets/img/logo.svg')) ?>" alt="Savian Canteen" class="logo-img" />
    <p class="tagline">Canteen System</p>
    <p class="sub">Order with your School ID · Fast &amp; Simple</p>

    <div class="landing-btns">
      <button type="button" class="btn btn-outline" id="open-order">Student / Employee Order</button>
      <a class="btn btn-outline" href="<?= e(base_url('admin/login.php')) ?>">Admin / Kitchen Login</a>
    </div>
  </div>

  <dialog class="role-modal" id="role-modal">
    <h3>Student / Employee Order</h3>
    <p class="lead">Choose Student or Employee, Then put School ID Number</p>

    <?php if ($error !== ''): ?>
      <div class="error-msg"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post">
      <input type="hidden" name="action" value="login" />

      <div class="role-toggle">
        <input type="radio" name="role" id="role-student" value="student" <?= $selected_role === 'student' ? 'checked' : '' ?>>
        <label for="role-student">Student</label>

        <input type="radio" name="role" id="role-employee" value="employee" <?= $selected_role === 'employee' ? 'checked' : '' ?>>
        <label for="role-employee">Employee</label>
      </div>

      <input type="text" name="school_id" required autocomplete="off"
             placeholder="Enter your ID Number"
             value="<?= e($_POST['school_id'] ?? '') ?>" />
      <button type="submit" class="btn btn-primary">Continue to Menu →</button>
    </form>

    <?php if ($enable_guest): ?>
      <div class="divider">— or —</div>
      <form method="post">
        <input type="hidden" name="action" value="guest" />
        <button type="submit" class="btn btn-outline">Continue as Guest / Outsider</button>
      </form>
    <?php endif; ?>

    <button type="button" class="close-link" id="close-order">Cancel</button>
  </dialog>

  <script>
    const modal = document.getElementById('role-modal');
    document.getElementById('open-order').addEventListener('click', () => modal.showModal());
    document.getElementById('close-order').addEventListener('click', () => modal.close());
    modal.addEventListener('click', e => { if (e.target === modal) modal.close(); });
    <?php if ($error !== ''): ?>
    modal.showModal();
    <?php endif; ?>
  </script>
</body>
</html>